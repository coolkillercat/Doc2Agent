import requests
import json
from urllib.parse import quote

def get_shopping_admin_auth_token():
    ENDPOINT = 'http://ec2-3-129-135-45.us-east-2.compute.amazonaws.com:7770'
    response = requests.post(
        url = f'{ENDPOINT}/rest/default/V1/integration/admin/token',
        headers = {
            'content-type': 'application/json'
        },
        data = json.dumps({
            'username': 'admin',
            'password': 'admin1234'
        })
    )
    return "Bearer " + response.json()

def retrieve_specific_attribute(attributeCode=None):
    """
    Retrieve specific product attribute from Magento API.
    
    Args:
        attributeCode (str): The code of the attribute to retrieve (e.g., 'color', 'size', 'material')
        
    Returns:
        requests.Response: The API response object
        
    Examples:
        >>> response = retrieve_specific_attribute(attributeCode='color')
        >>> response = retrieve_specific_attribute(attributeCode='size')
    """
    assert attributeCode is not None, 'Missing required parameter: attributeCode'
    
    base_url = "http://ec2-3-129-135-45.us-east-2.compute.amazonaws.com:7770"
    api_url = f"{base_url}/rest/default/V1/products/attributes/{quote(attributeCode, safe='')}"
    
    headers = {
        'Content-Type': 'application/json', 
        'Authorization': get_shopping_admin_auth_token()
    }
    
    response = requests.get(url=api_url, headers=headers, timeout=50, verify=False)
    return response

if __name__ == '__main__':
    r = retrieve_specific_attribute(attributeCode='color')
    r_json = None
    try:
        r_json = r.json()
    except:
        pass
    result_dict = dict()
    result_dict['status_code'] = r.status_code
    result_dict['text'] = r.text
    result_dict['json'] = r_json
    result_dict['content'] = r.content.decode("utf-8")
    print(json.dumps(result_dict, indent=4))